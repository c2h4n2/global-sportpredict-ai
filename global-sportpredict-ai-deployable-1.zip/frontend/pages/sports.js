const sports = [
  { name: 'Soccer', features: ['xG', 'xGA', 'formations', 'pressing', 'cards', 'set pieces'] },
  { name: 'Basketball', features: ['pace', 'net rating', 'true shooting', 'rebound rate', 'bench depth'] },
  { name: 'American Football', features: ['EPA', 'DVOA', 'QB rating', 'red zone', 'special teams'] },
  { name: 'Baseball', features: ['ERA', 'WHIP', 'OPS', 'WAR', 'starter matchup', 'park factor'] },
  { name: 'Hockey', features: ['Corsi', 'Fenwick', 'save %', 'GSAx', 'power play'] },
  { name: 'Tennis', features: ['surface record', 'serve %', 'break points', 'H2H', 'fatigue'] },
  { name: 'Cricket', features: ['pitch', 'toss', 'strike rate', 'economy', 'dew factor'] },
  { name: 'Rugby', features: ['scrum', 'lineout', 'territory', 'kicking', 'discipline'] },
  { name: 'Volleyball', features: ['serve receive', 'attack efficiency', 'blocks', 'rotation matchups'] },
  { name: 'MMA/UFC', features: ['reach', 'striking accuracy', 'takedowns', 'submissions', 'cardio'] },
  { name: 'Boxing', features: ['reach', 'power', 'defense', 'chin', 'stamina'] },
  { name: 'Formula 1', features: ['qualifying', 'race pace', 'tires', 'pit stops', 'safety car'] },
  { name: 'NASCAR', features: ['track type', 'long-run speed', 'pit crew', 'cautions'] },
  { name: 'Golf', features: ['strokes gained', 'course fit', 'putting', 'wind'] },
  { name: 'Esports', features: ['map pool', 'patch meta', 'role matchups', 'roster changes'] }
];

export default function Sports() {
  return <main className="page"><nav className="nav"><div className="brand">Global SportPredict AI</div><div className="links"><a href="/">Home</a><a href="/sports">Sports</a><a href="/platform">Platform</a></div></nav><section className="modules"><h1 className="pageTitle">Sports coverage</h1><p>Each sport uses the shared 25-factor engine plus sport-specific features and scoring logic.</p><div className="sportGrid">{sports.map(s => <article className="sportCard" key={s.name}><h2>{s.name}</h2><div className="pillRow">{s.features.map(f => <span className="pill" key={f}>{f}</span>)}</div></article>)}</div></section></main>;
}
